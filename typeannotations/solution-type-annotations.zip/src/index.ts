const app = document.getElementById("app");
if (app) {
  app.innerHTML = `
  <h1>Type Annotations</h1>
  <p>The code for this practice is in the <code>src/annotations.ts</code> file. All you have to do is open that file up and add the necessary type annotations to remove the red squiggles.
  `;
}
